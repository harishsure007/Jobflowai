def parse_resume(text):
    # Dummy parser logic (replace with your own)
    return {
        "skills": ["Python", "Flask", "AI"],
        "experience_years": 3,
        "summary": "This is a dummy parsed resume."
    }
